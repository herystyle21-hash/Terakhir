async function downloadVideo() {
  const url = document.getElementById("url").value;
  const status = document.getElementById("status");
  status.textContent = "Mengambil link...";
  const res = await fetch(`/api/download?url=${encodeURIComponent(url)}`);
  const data = await res.json();
  if (data.download_url) {
    status.textContent = "Sukses! Sedang mengunduh...";
    window.location = data.download_url;
  } else {
    status.textContent = "Gagal mengambil video!";
  }
}
