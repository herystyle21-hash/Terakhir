export default async function handler(req, res) {
  const url = req.query.url;
  if (!url) return res.status(400).json({ error: "URL tidak ditemukan" });
  try {
    const api = `https://api.tikmate.app/api/lookup?url=${encodeURIComponent(url)}`;
    const result = await fetch(api);
    const data = await result.json();
    if (!data || !data.video_url) return res.status(500).json({ error: "Gagal mendapatkan data" });
    res.status(200).json({
      download_url: "https://tikmate.app/download/" + data.token + "/" + data.id + ".mp4"
    });
  } catch (e) {
    res.status(500).json({ error: "Server error" });
  }
}
